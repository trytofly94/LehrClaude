---
name: mat-02-arbeitsblatt-erstellen
description: "Dieser Skill sollte verwendet werden, wenn Arbeitsblätter erstellt und professionell formatiert werden müssen für Schüler und Lehrkräfte. Er transformiert Lerninhalte in strukturierte, differenzierte Arbeitsblätter mit Aufgaben auf verschiedenen Kompetenzstufen (Basis, Unterstützung, Erweiterung), inklusive Lernhilfen und Lehrerlösungen. Dieser Skill wird ausgelöst, wenn professionelle, pädagogisch fundierte Arbeitsblätter aus Unterrichtsmaterial erstellt werden sollen."
---

# Arbeitsblatt erstellen und formatieren

## Skill-Zweck

Dieser Skill erstellt vollständige, professionell formatierte Arbeitsblätter für den Unterricht. Er nimmt bestehendes Unterrichtsmaterial und verwandelt es in strukturierte Arbeitsblätter, die evidenzbasierten pädagogischen Designprinzipien folgen, einschließlich differenzierter Lernwege für Schüler auf verschiedenen Kompetenzstufen (Wembers Differenzierungsmodell: Basisstufe, Unterstützungsstufe, Erweiterungsstufe).

Der Skill generiert drei Arten von Materialien im strukturierten Markdown-Format:
1. **Schüler-Arbeitsblätter** - Strukturierte Lernmaterialien mit progressiven Aufgaben
2. **Gestufte Lernhilfen** - Gestaffelte Unterstützung auf drei Kompetenzstufen
3. **Unterrichtsmaterial** - Dokumentation des Unterrichtsverlaufs mit Lehrerlösungen

## Wann dieser Skill verwendet werden sollte

Aktiviere diesen Skill, wenn:
- Arbeitsblätter für ein spezifisches Lernziel oder Feinziel erstellt werden sollen
- Inhalte in lerngerechte Materialien für verschiedene Kompetenzstufen strukturiert werden müssen
- Differenzierter Unterricht gestaltet wird, der Schüler mit unterschiedlichem Unterstützungsbedarf anspricht
- Materialien erstellt werden, die konsistente Formatierung und pädagogische Struktur erfordern
- Umfassende Arbeitsblatt-Sets erstellt werden, die sowohl Schülermaterialien als auch Lehrerlösungen umfassen

## Skill-Workflow

### Schritt 1: Arbeitsblatt-Strukturplanung

Bevor Arbeitsblätter erstellt werden, kläre das Ausgangsmaterial und die Lernziele:
- Bestätige, welche Feinziele die Arbeitsblätter adressieren
- Verifiziere das Fachgebiet und die Klassenstufe der Schüler
- Identifiziere Kernthemen und Unterthemen, die behandelt werden sollen
- Bestimme die Anzahl und den Umfang der benötigten Arbeitsblätter

### Schritt 2: Erstellung der Schüler-Arbeitsblätter

Erstelle Arbeitsblätter nach dieser strikten Struktur für jedes Thema:

**Kopfzeilen-Bereich:**
- Titel: Thema/Themengebiet
- Klare, altersgerechte Überschrift

**Inhalts-Bereich:**
- **Überarbeiteter Sachtext / Informationstext** - Aufbereiteter Informationstext, der:
  - Inhalte klar und prägnant präsentiert
  - Angemessenes Vokabular für die Zielklassenstufe verwendet
  - Notwendige Erklärungen und Kontext einbezieht
  - Fachliche Genauigkeit ohne Jargon-Überladung wahrt

- **Wortspeicher** - Wesentliche Terminologie:
  - Liste der wichtigsten Fachbegriffe, die im Text verwendet werden
  - Kurze, schülerfreundliche Definitionen
  - Visuelle Hilfen oder Kontext, wo hilfreich

**Aufgaben-Bereich:**
- **Aufgabenstellungen** organisiert nach Kompetenzstufen:
  - **Basisstufe**: Grundlegende Aufgaben mit Fokus auf Wiedergabe und Verständnis
    - Aktivitäten zur Überprüfung des Verständnisses der Kernkonzepte
    - Strukturierte Formate (Zuordnung, Beschriftung, einfache Erklärungen)
  - **Unterstützungsstufe**: Mittlere Aufgaben mit gestaffelter Unterstützung
    - Aufgaben, die Konzepte in angeleiteten Kontexten anwenden
    - Enthält Teillösungen oder anleitende Fragen
    - Baut Brücke zwischen grundlegendem Verständnis und eigenständiger Arbeit
  - **Erweiterungsstufe**: Fortgeschrittene Aufgaben für vertieftes Engagement
    - Höhere Denkprozesse (Analyse, Synthese, Bewertung)
    - Offene Problemstellungen, die kreatives oder kritisches Denken erfordern
    - Verbindungen zu breiteren Konzepten oder realen Anwendungen

**Lösungs-Bereich:**
- **Lösungen** - Vollständige Lösungen für alle Aufgaben:
  - Detaillierte Lösungsschlüssel für jede Kompetenzstufe
  - Erklärungen der Begründung, wo relevant
  - Alternative akzeptable Antworten vermerkt

**Material-Liste:**
- **Übersicht fehlende Materialien und Grafiken** - Inventar benötigter Ressourcen:
  - Identifiziere fehlende Grafiken (Tabellen, Diagramme, Schaubilder, Graphen, Bilder)
  - Vermerke, wo visuelles Material eingefügt werden sollte
  - Spezifiziere Art und Zweck jeder Grafik
  - Markiere Platzierungsort deutlich

### Schritt 3: Erstellung gestufter Lernhilfen

Erstelle gestaffelte Unterstützungsmaterialien organisiert nach Kompetenzstufen. Für jede Stufe biete:

**Kopfzeilen-Bereich:**
- Titel: Thema/Themengebiet

**Lernhilfe-Inhalt:**
- **Gestufte Lernhilfe zur Basisstufe** - Unterstützung auf Grundstufe:
  - Vereinfachte Erklärungen der Kernkonzepte
  - Schritt-für-Schritt-Anleitung für Basisaufgaben
  - Visuelle Strukturierungshilfen oder grafische Unterstützung
  - Vokabularhilfe und Definitionszugang

- **Gestufte Lernhilfe zur Unterstützungsstufe** - Mittlere Unterstützung:
  - Angeleitete Problemlösungsstrategien
  - Strukturierte Fragesequenzen, die selbstständiges Denken fördern
  - Teilmodelle oder durchgearbeitete Beispiele
  - Checkliste zur Aufgabenbearbeitung

- **Gestufte Lernhilfe zur Erweiterungsstufe** - Erweiterte Unterstützung:
  - Anleitende Fragen für tiefere Analyse
  - Ressourcenlisten für eigenständige Recherche
  - Erweiterungen zu realen Kontexten
  - Verbindung zu breiteren Konzepten oder fächerübergreifenden Verknüpfungen

### Schritt 4: Erstellung des Unterrichtsmaterials

Erstelle umfassende Unterrichtsdokumentation mit dieser Struktur:

**Kopfzeilen-Bereich:**
- Titel: Thema/Themengebiet

**Lernziel-Bereich:**
- **Lernziele** mit klarer Hierarchie:
  - **Grobziel** - Übergeordnetes Lernziel für die gesamte Einheit
  - **Feinziele** - Spezifische, messbare Ziele
    - Formuliert nach SMART-Kriterien (Spezifisch, Messbar, Akzeptiert, Realistisch, Terminiert)
    - Referenz zur Bloom-Taxonomie-Stufe, wo angemessen

**Unterrichtsverlaufs-Dokumentation:**
- **Tabelle Unterrichtsverlaufsplanung** - Strukturierte Unterrichtsplanung:
  - Basierend auf Leisens 6-Phasen-Unterrichtsmodell
  - Phasen: Einstieg, Erarbeitung, Sicherung, Vernetzen, Anwendung, Transfer
  - Zeitliche Einteilung für jede Phase
  - Unterrichtsmethoden und Aktivitäten pro Phase
  - Benötigte Materialien und Ressourcen

**Lehrerlösungen:**
- **Lösungen zu den Phasen "Sichern und Vernetzen" und "Anwendung und Transfer"** - Detaillierte Lösungen:
  - Vollständige ausgearbeitete Lösungen für Sicherungsphase-Aufgaben
  - Vernetzungs-/Syntheselösungen, die konzeptuelle Verbindungen zeigen
  - Anwendungsphase-Lösungen mit erwarteten Schülerantworten
  - Transferphase-Lösungen mit Differenzierungsoptionen
  - Mögliche Schülermisskonzeptionen und Korrekturstrategien

## Referenzmaterialien & Vorlagen

Greife auf diese Referenzmaterialien vom MCP Filesystem Server unter `2_Zentrale_Ressourcen/` zu:

- **arbeitsblatt-vorlage.md** - Standard-Arbeitsblatt-Layout-Vorlage
  - Markdown-Formatierungsrichtlinien
  - Standards zur Abschnittsorganisation
  - Typografie- und Abstandskonventionen
  - Beispiele fertiggestellter Arbeitsblätter

Verwende diese Vorlage, um konsistente Markdown-Formatierung und professionelles Erscheinungsbild über alle Arbeitsblätter hinweg sicherzustellen.

## Qualitätsstandards für Inhalte

Beim Erstellen von Arbeitsblättern stelle sicher:

- **Keine Inhaltsabkürzung**: Vollständige Informationen wie in den Anforderungen spezifiziert beibehalten
  - Erklärungen nicht verkürzen oder unterstützende Details entfernen
  - Vollständige Beispiele und anschauliches Material einbeziehen
  - Pädagogisch notwendige Wiederholung und Verstärkung bewahren

- **Pädagogische Genauigkeit**: Evidenzbasiertem Instruktionsdesign folgen
  - Aufgaben schreiten logisch von grundlegend zu fortgeschritten voran
  - Differenzierung dient tatsächlich unterschiedlichen Lernerbedürfnissen
  - Lernhilfen bieten echte Gerüste
  - Lehrerlösungen ermöglichen professionelle Beurteilung

- **Klarheit & Zugänglichkeit**:
  - Sprache angemessen für Zielklassenstufe
  - Klare Aufgabenanweisungen ohne Mehrdeutigkeit
  - Durchgehend konsistente Formatierung
  - Explizite Verbindung zwischen Materialien und Lernzielen

- **Vollständigkeit**:
  - Alle drei Kompetenzstufen repräsentiert
  - Alle Aufgaben haben entsprechende Lösungen
  - Alle Grafik-/Materialbedarfe identifiziert
  - Unterrichtsmaterial ausreichend für Umsetzung

## Klärung & Verifizierungsprozess

Vor Fertigstellung der Arbeitsblatt-Erstellung:

1. **Anforderungen prüfen**: Verständnis aller Spezifikationen bestätigen
2. **Abdeckung überprüfen**: Verifizieren, dass alle Feinziele adressiert werden
3. **Differenzierung validieren**: Sicherstellen, dass Aufgaben echte Unterrichtsdifferenzierung bieten
4. **Sprache optimieren**: Text für Klarheit und pädagogische Angemessenheit verfeinern
5. **Zur Bestätigung vorlegen**: Optimierte Version dem Nutzer zur Genehmigung vorlegen, bevor finalisiert wird

Folge diesem Prozess: Lies zuerst die gesamte Anfrage, optimiere den Ansatz, präsentiere die optimierte Version dem Nutzer zur Bestätigung und führe erst nach ausdrücklicher Genehmigung aus.

## Integrations-Hinweise

Dieser Skill arbeitet koordiniert mit:
- **export-md** - Export als Markdown
- **export-pdf** - Finaler Export als PDF
- **export-docx** - Finaler Export als DOCX
- **export-pptx** - Export als PowerPoint

---

**Skill-Typ**: Materialerstellung
**Lerntheoretische Basis**: Wembers Differenzierungsmodell, Bloom-Taxonomie, Leisens Phasenmodell
**Ausgabeformat**: Markdown-strukturierte Arbeitsblätter (.md Format)

## Markdown-Formatierungsregeln

WICHTIG: Alle Outputs MÜSSEN im strukturierten Markdown-Format erstellt werden.

**Formatierungsregeln:**

**Überschriften:**
```markdown
# Hauptüberschrift

## Unterüberschrift

### Abschnittsüberschrift
```

**Listen:**
```markdown
- Listenpunkt 1
- Listenpunkt 2
  - Unterpunkt (2 Leerzeichen Einrückung)
```

**Hervorhebungen:**
```markdown
**Fett gedruckt** für wichtige Begriffe
*Kursiv* für betonte Texte
```

**Abschnitte:**
Verwende klare Überschriften und Leerzeilen zwischen Abschnitten.

**Dateiendung:** Alle generierten Dateien erhalten die Endung `.md`

## Resources

Dieser Skill nutzt folgende Ressourcen:

- **Templates:** Vorlagen für Unterrichtsmaterialien (noch nicht implementiert)
- **Daten:** Beispiele und Referenzmaterialien (noch nicht implementiert)

Zukünftige Erweiterungen werden in `resources/` abgelegt.

## Next Steps

Nach Erstellung des Materials:
- Der Nutzer kann das Ergebnis überprüfen und anpassen
- Das Material kann exportiert werden (export-md, export-pdf, export-docx)
- Weitere Materialien können erstellt werden
